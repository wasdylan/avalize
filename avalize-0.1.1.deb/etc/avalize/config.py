import sqlite3
import os

datadir = os.path.expanduser(os.path.join('~', '.avalize'))
if not os.path.exists(datadir):
    os.makedirs(datadir)
    assert os.path.exists(datadir)

conn = sqlite3.connect(datadir+"/data.db")
cursor = conn.cursor()
cursor.execute("""CREATE TABLE filelist (
               id INTEGER PRIMARY KEY,
               filepath text
               ) 
               """)
conn.close()
